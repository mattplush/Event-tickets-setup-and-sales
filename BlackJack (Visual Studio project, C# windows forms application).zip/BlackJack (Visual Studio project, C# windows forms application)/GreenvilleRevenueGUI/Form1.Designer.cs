﻿namespace GreenvilleRevenueGUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.DLabel3 = new System.Windows.Forms.Label();
            this.DLabel4 = new System.Windows.Forms.Label();
            this.DLabel5 = new System.Windows.Forms.Label();
            this.PLabel1 = new System.Windows.Forms.Label();
            this.PLabel2 = new System.Windows.Forms.Label();
            this.PLabel3 = new System.Windows.Forms.Label();
            this.PLabel4 = new System.Windows.Forms.Label();
            this.PLabel5 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.DLabel2 = new System.Windows.Forms.Label();
            this.DLabel1 = new System.Windows.Forms.Label();
            this.playerBetChange = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.DScore = new System.Windows.Forms.Label();
            this.PScore = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.Label();
            this.AllInButton = new System.Windows.Forms.Button();
            this.PCard5 = new System.Windows.Forms.Button();
            this.HitButton = new System.Windows.Forms.Button();
            this.StayButton = new System.Windows.Forms.Button();
            this.PCard4 = new System.Windows.Forms.Button();
            this.PCard2 = new System.Windows.Forms.Button();
            this.PCard1 = new System.Windows.Forms.Button();
            this.DCard4 = new System.Windows.Forms.Button();
            this.DCard1 = new System.Windows.Forms.Button();
            this.DCard5 = new System.Windows.Forms.Button();
            this.DCard3 = new System.Windows.Forms.Button();
            this.PCard3 = new System.Windows.Forms.Button();
            this.DCard2 = new System.Windows.Forms.Button();
            this.StartButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.playerBetChange)).BeginInit();
            this.SuspendLayout();
            // 
            // DLabel3
            // 
            this.DLabel3.AutoSize = true;
            this.DLabel3.BackColor = System.Drawing.Color.Transparent;
            this.DLabel3.Font = new System.Drawing.Font("MV Boli", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DLabel3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.DLabel3.Location = new System.Drawing.Point(611, 346);
            this.DLabel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.DLabel3.Name = "DLabel3";
            this.DLabel3.Size = new System.Drawing.Size(0, 37);
            this.DLabel3.TabIndex = 28;
            this.DLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DLabel4
            // 
            this.DLabel4.AutoSize = true;
            this.DLabel4.BackColor = System.Drawing.Color.Transparent;
            this.DLabel4.Font = new System.Drawing.Font("MV Boli", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DLabel4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.DLabel4.Location = new System.Drawing.Point(754, 346);
            this.DLabel4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.DLabel4.Name = "DLabel4";
            this.DLabel4.Size = new System.Drawing.Size(0, 37);
            this.DLabel4.TabIndex = 30;
            this.DLabel4.Click += new System.EventHandler(this.label4_Click);
            // 
            // DLabel5
            // 
            this.DLabel5.AutoSize = true;
            this.DLabel5.BackColor = System.Drawing.Color.Transparent;
            this.DLabel5.Font = new System.Drawing.Font("MV Boli", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DLabel5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.DLabel5.Location = new System.Drawing.Point(897, 346);
            this.DLabel5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.DLabel5.Name = "DLabel5";
            this.DLabel5.Size = new System.Drawing.Size(0, 37);
            this.DLabel5.TabIndex = 31;
            // 
            // PLabel1
            // 
            this.PLabel1.AutoSize = true;
            this.PLabel1.BackColor = System.Drawing.Color.Transparent;
            this.PLabel1.Font = new System.Drawing.Font("MV Boli", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PLabel1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.PLabel1.Location = new System.Drawing.Point(322, 677);
            this.PLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.PLabel1.Name = "PLabel1";
            this.PLabel1.Size = new System.Drawing.Size(0, 37);
            this.PLabel1.TabIndex = 32;
            this.PLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PLabel2
            // 
            this.PLabel2.AutoSize = true;
            this.PLabel2.BackColor = System.Drawing.Color.Transparent;
            this.PLabel2.Font = new System.Drawing.Font("MV Boli", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PLabel2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.PLabel2.Location = new System.Drawing.Point(465, 677);
            this.PLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.PLabel2.Name = "PLabel2";
            this.PLabel2.Size = new System.Drawing.Size(0, 37);
            this.PLabel2.TabIndex = 33;
            this.PLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PLabel3
            // 
            this.PLabel3.AutoSize = true;
            this.PLabel3.BackColor = System.Drawing.Color.Transparent;
            this.PLabel3.Font = new System.Drawing.Font("MV Boli", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PLabel3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.PLabel3.Location = new System.Drawing.Point(611, 677);
            this.PLabel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.PLabel3.Name = "PLabel3";
            this.PLabel3.Size = new System.Drawing.Size(0, 37);
            this.PLabel3.TabIndex = 34;
            this.PLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PLabel4
            // 
            this.PLabel4.AutoSize = true;
            this.PLabel4.BackColor = System.Drawing.Color.Transparent;
            this.PLabel4.Font = new System.Drawing.Font("MV Boli", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PLabel4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.PLabel4.Location = new System.Drawing.Point(754, 677);
            this.PLabel4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.PLabel4.Name = "PLabel4";
            this.PLabel4.Size = new System.Drawing.Size(0, 37);
            this.PLabel4.TabIndex = 35;
            this.PLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PLabel5
            // 
            this.PLabel5.AutoSize = true;
            this.PLabel5.BackColor = System.Drawing.Color.Transparent;
            this.PLabel5.Font = new System.Drawing.Font("MV Boli", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PLabel5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.PLabel5.Location = new System.Drawing.Point(897, 677);
            this.PLabel5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.PLabel5.Name = "PLabel5";
            this.PLabel5.Size = new System.Drawing.Size(0, 37);
            this.PLabel5.TabIndex = 36;
            this.PLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar;
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("MV Boli", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label14.Location = new System.Drawing.Point(13, 510);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(247, 95);
            this.label14.TabIndex = 37;
            this.label14.Text = "Player";
            // 
            // label15
            // 
            this.label15.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar;
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("MV Boli", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label15.Location = new System.Drawing.Point(13, 179);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(247, 95);
            this.label15.TabIndex = 38;
            this.label15.Text = "Dealer";
            // 
            // DLabel2
            // 
            this.DLabel2.AutoSize = true;
            this.DLabel2.BackColor = System.Drawing.Color.Transparent;
            this.DLabel2.Font = new System.Drawing.Font("MV Boli", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DLabel2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.DLabel2.Location = new System.Drawing.Point(465, 346);
            this.DLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.DLabel2.Name = "DLabel2";
            this.DLabel2.Size = new System.Drawing.Size(0, 37);
            this.DLabel2.TabIndex = 46;
            this.DLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DLabel1
            // 
            this.DLabel1.AutoSize = true;
            this.DLabel1.BackColor = System.Drawing.Color.Transparent;
            this.DLabel1.Font = new System.Drawing.Font("MV Boli", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DLabel1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.DLabel1.Location = new System.Drawing.Point(322, 343);
            this.DLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.DLabel1.Name = "DLabel1";
            this.DLabel1.Size = new System.Drawing.Size(0, 37);
            this.DLabel1.TabIndex = 47;
            this.DLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // playerBetChange
            // 
            this.playerBetChange.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.playerBetChange.Cursor = System.Windows.Forms.Cursors.Default;
            this.playerBetChange.Font = new System.Drawing.Font("Myanmar Text", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playerBetChange.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.playerBetChange.Location = new System.Drawing.Point(428, 745);
            this.playerBetChange.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.playerBetChange.Name = "playerBetChange";
            this.playerBetChange.ReadOnly = true;
            this.playerBetChange.Size = new System.Drawing.Size(200, 97);
            this.playerBetChange.TabIndex = 53;
            this.playerBetChange.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.playerBetChange.ThousandsSeparator = true;
            this.playerBetChange.ValueChanged += new System.EventHandler(this.playerBetChange_ValueChanged);
            // 
            // label1
            // 
            this.label1.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("MV Boli", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(407, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(517, 125);
            this.label1.TabIndex = 55;
            this.label1.Text = "Black-Jack";
            // 
            // DScore
            // 
            this.DScore.AutoSize = true;
            this.DScore.BackColor = System.Drawing.Color.Transparent;
            this.DScore.Font = new System.Drawing.Font("MV Boli", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DScore.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.DScore.Location = new System.Drawing.Point(69, 274);
            this.DScore.Name = "DScore";
            this.DScore.Size = new System.Drawing.Size(0, 52);
            this.DScore.TabIndex = 56;
            this.DScore.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PScore
            // 
            this.PScore.AutoSize = true;
            this.PScore.BackColor = System.Drawing.Color.Transparent;
            this.PScore.Font = new System.Drawing.Font("MV Boli", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PScore.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.PScore.Location = new System.Drawing.Point(112, 605);
            this.PScore.Name = "PScore";
            this.PScore.Size = new System.Drawing.Size(0, 52);
            this.PScore.TabIndex = 57;
            this.PScore.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // textBox2
            // 
            this.textBox2.AutoSize = true;
            this.textBox2.Font = new System.Drawing.Font("Myanmar Text", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(30, 745);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(65, 85);
            this.textBox2.TabIndex = 58;
            this.textBox2.Text = "0";
            this.textBox2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AllInButton
            // 
            this.AllInButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.AllInButton.Font = new System.Drawing.Font("Myanmar Text", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AllInButton.Location = new System.Drawing.Point(674, 745);
            this.AllInButton.Name = "AllInButton";
            this.AllInButton.Size = new System.Drawing.Size(135, 97);
            this.AllInButton.TabIndex = 60;
            this.AllInButton.Text = "All in!";
            this.AllInButton.UseVisualStyleBackColor = false;
            this.AllInButton.Click += new System.EventHandler(this.AllInButton_Click);
            // 
            // PCard5
            // 
            this.PCard5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PCard5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.PCard5.Image = global::GreenvilleRevenueGUI.Properties.Resources.USD0490860_20040601_D00000;
            this.PCard5.Location = new System.Drawing.Point(863, 510);
            this.PCard5.Margin = new System.Windows.Forms.Padding(2);
            this.PCard5.Name = "PCard5";
            this.PCard5.Size = new System.Drawing.Size(125, 165);
            this.PCard5.TabIndex = 45;
            this.PCard5.UseVisualStyleBackColor = true;
            this.PCard5.Click += new System.EventHandler(this.PCard5_Click);
            // 
            // HitButton
            // 
            this.HitButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.HitButton.Image = global::GreenvilleRevenueGUI.Properties.Resources.hitme125x78;
            this.HitButton.Location = new System.Drawing.Point(1078, 343);
            this.HitButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.HitButton.Name = "HitButton";
            this.HitButton.Size = new System.Drawing.Size(187, 166);
            this.HitButton.TabIndex = 41;
            this.HitButton.UseVisualStyleBackColor = true;
            this.HitButton.Click += new System.EventHandler(this.HitButton_Click);
            // 
            // StayButton
            // 
            this.StayButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StayButton.Image = global::GreenvilleRevenueGUI.Properties.Resources.staybutton125x100;
            this.StayButton.Location = new System.Drawing.Point(1078, 632);
            this.StayButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.StayButton.Name = "StayButton";
            this.StayButton.Size = new System.Drawing.Size(187, 166);
            this.StayButton.TabIndex = 39;
            this.StayButton.UseVisualStyleBackColor = true;
            this.StayButton.Click += new System.EventHandler(this.StayButton_Click);
            // 
            // PCard4
            // 
            this.PCard4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PCard4.Image = global::GreenvilleRevenueGUI.Properties.Resources.USD0490860_20040601_D00000;
            this.PCard4.Location = new System.Drawing.Point(716, 510);
            this.PCard4.Margin = new System.Windows.Forms.Padding(2);
            this.PCard4.Name = "PCard4";
            this.PCard4.Size = new System.Drawing.Size(125, 165);
            this.PCard4.TabIndex = 27;
            this.PCard4.UseVisualStyleBackColor = true;
            this.PCard4.Click += new System.EventHandler(this.PCard4_Click);
            // 
            // PCard2
            // 
            this.PCard2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PCard2.Image = global::GreenvilleRevenueGUI.Properties.Resources.USD0490860_20040601_D00000;
            this.PCard2.Location = new System.Drawing.Point(426, 510);
            this.PCard2.Margin = new System.Windows.Forms.Padding(2);
            this.PCard2.Name = "PCard2";
            this.PCard2.Size = new System.Drawing.Size(125, 165);
            this.PCard2.TabIndex = 26;
            this.PCard2.UseVisualStyleBackColor = true;
            this.PCard2.Click += new System.EventHandler(this.PCard2_Click);
            // 
            // PCard1
            // 
            this.PCard1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PCard1.Image = global::GreenvilleRevenueGUI.Properties.Resources.USD0490860_20040601_D00000;
            this.PCard1.Location = new System.Drawing.Point(283, 510);
            this.PCard1.Margin = new System.Windows.Forms.Padding(2);
            this.PCard1.Name = "PCard1";
            this.PCard1.Size = new System.Drawing.Size(125, 165);
            this.PCard1.TabIndex = 24;
            this.PCard1.UseVisualStyleBackColor = true;
            this.PCard1.Click += new System.EventHandler(this.PCard1_Click);
            // 
            // DCard4
            // 
            this.DCard4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.DCard4.Image = global::GreenvilleRevenueGUI.Properties.Resources.USD0490860_20040601_D00000;
            this.DCard4.Location = new System.Drawing.Point(716, 179);
            this.DCard4.Margin = new System.Windows.Forms.Padding(2);
            this.DCard4.Name = "DCard4";
            this.DCard4.Size = new System.Drawing.Size(125, 165);
            this.DCard4.TabIndex = 23;
            this.DCard4.UseVisualStyleBackColor = true;
            // 
            // DCard1
            // 
            this.DCard1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.DCard1.Image = global::GreenvilleRevenueGUI.Properties.Resources.USD0490860_20040601_D00000;
            this.DCard1.Location = new System.Drawing.Point(283, 179);
            this.DCard1.Margin = new System.Windows.Forms.Padding(2);
            this.DCard1.Name = "DCard1";
            this.DCard1.Size = new System.Drawing.Size(125, 165);
            this.DCard1.TabIndex = 22;
            this.DCard1.UseVisualStyleBackColor = true;
            // 
            // DCard5
            // 
            this.DCard5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.DCard5.Image = global::GreenvilleRevenueGUI.Properties.Resources.USD0490860_20040601_D00000;
            this.DCard5.Location = new System.Drawing.Point(863, 179);
            this.DCard5.Margin = new System.Windows.Forms.Padding(2);
            this.DCard5.Name = "DCard5";
            this.DCard5.Size = new System.Drawing.Size(125, 165);
            this.DCard5.TabIndex = 21;
            this.DCard5.UseVisualStyleBackColor = true;
            // 
            // DCard3
            // 
            this.DCard3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.DCard3.Image = global::GreenvilleRevenueGUI.Properties.Resources.USD0490860_20040601_D00000;
            this.DCard3.Location = new System.Drawing.Point(572, 179);
            this.DCard3.Margin = new System.Windows.Forms.Padding(2);
            this.DCard3.Name = "DCard3";
            this.DCard3.Size = new System.Drawing.Size(125, 165);
            this.DCard3.TabIndex = 20;
            this.DCard3.UseVisualStyleBackColor = true;
            // 
            // PCard3
            // 
            this.PCard3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PCard3.Image = global::GreenvilleRevenueGUI.Properties.Resources.USD0490860_20040601_D00000;
            this.PCard3.Location = new System.Drawing.Point(572, 510);
            this.PCard3.Margin = new System.Windows.Forms.Padding(2);
            this.PCard3.Name = "PCard3";
            this.PCard3.Size = new System.Drawing.Size(125, 165);
            this.PCard3.TabIndex = 19;
            this.PCard3.UseVisualStyleBackColor = true;
            this.PCard3.Click += new System.EventHandler(this.PCard3_Click);
            // 
            // DCard2
            // 
            this.DCard2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.DCard2.Image = global::GreenvilleRevenueGUI.Properties.Resources.USD0490860_20040601_D00000;
            this.DCard2.Location = new System.Drawing.Point(426, 179);
            this.DCard2.Margin = new System.Windows.Forms.Padding(2);
            this.DCard2.Name = "DCard2";
            this.DCard2.Size = new System.Drawing.Size(125, 165);
            this.DCard2.TabIndex = 18;
            this.DCard2.UseVisualStyleBackColor = true;
            // 
            // StartButton
            // 
            this.StartButton.BackColor = System.Drawing.Color.Transparent;
            this.StartButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("StartButton.BackgroundImage")));
            this.StartButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.StartButton.Location = new System.Drawing.Point(1078, 66);
            this.StartButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.StartButton.Name = "StartButton";
            this.StartButton.Size = new System.Drawing.Size(187, 166);
            this.StartButton.TabIndex = 8;
            this.StartButton.UseVisualStyleBackColor = false;
            this.StartButton.Click += new System.EventHandler(this.StartButton_Click);
            // 
            // label2
            // 
            this.label2.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar;
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("MV Boli", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(340, 745);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 95);
            this.label2.TabIndex = 61;
            this.label2.Text = "$";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BackgroundImage = global::GreenvilleRevenueGUI.Properties.Resources.felt;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1303, 944);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.AllInButton);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.PScore);
            this.Controls.Add(this.DScore);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.playerBetChange);
            this.Controls.Add(this.DLabel1);
            this.Controls.Add(this.DLabel2);
            this.Controls.Add(this.PCard5);
            this.Controls.Add(this.HitButton);
            this.Controls.Add(this.StayButton);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.PLabel5);
            this.Controls.Add(this.PLabel4);
            this.Controls.Add(this.PLabel3);
            this.Controls.Add(this.PLabel2);
            this.Controls.Add(this.PLabel1);
            this.Controls.Add(this.DLabel5);
            this.Controls.Add(this.DLabel4);
            this.Controls.Add(this.DLabel3);
            this.Controls.Add(this.PCard4);
            this.Controls.Add(this.PCard2);
            this.Controls.Add(this.PCard1);
            this.Controls.Add(this.DCard4);
            this.Controls.Add(this.DCard1);
            this.Controls.Add(this.DCard5);
            this.Controls.Add(this.DCard3);
            this.Controls.Add(this.PCard3);
            this.Controls.Add(this.DCard2);
            this.Controls.Add(this.StartButton);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximumSize = new System.Drawing.Size(1325, 1000);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Black Jack";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.playerBetChange)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button StartButton;
        private System.Windows.Forms.Button DCard2;
        private System.Windows.Forms.Button PCard3;
        private System.Windows.Forms.Button DCard3;
        private System.Windows.Forms.Button DCard5;
        private System.Windows.Forms.Button DCard4;
        private System.Windows.Forms.Button PCard1;
        private System.Windows.Forms.Button PCard2;
        private System.Windows.Forms.Button PCard4;
        private System.Windows.Forms.Label DLabel3;
        private System.Windows.Forms.Label DLabel4;
        private System.Windows.Forms.Label DLabel5;
        private System.Windows.Forms.Label PLabel1;
        private System.Windows.Forms.Label PLabel2;
        private System.Windows.Forms.Label PLabel3;
        private System.Windows.Forms.Label PLabel4;
        private System.Windows.Forms.Label PLabel5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button StayButton;
        private System.Windows.Forms.Button HitButton;
        private System.Windows.Forms.Button PCard5;
        private System.Windows.Forms.Label DLabel2;
        private System.Windows.Forms.Label DLabel1;
        private System.Windows.Forms.NumericUpDown playerBetChange;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label DScore;
        private System.Windows.Forms.Label PScore;
        private System.Windows.Forms.Label textBox2;
        private System.Windows.Forms.Button AllInButton;
        private System.Windows.Forms.Button DCard1;
        private System.Windows.Forms.Label label2;
    }
}

